import {
  Cloud,
  Database,
  Shield,
  Smartphone,
  Sparkles,
  Workflow
} from "lucide-react";

import { Reveal } from "@/components/motion/reveal";
import { GlassCard } from "@/components/primitives/glass-card";
import { SectionHeader } from "@/components/primitives/section-header";
import type { Capability } from "@/lib/content/site-content";

const iconMap = {
  workflow: Workflow,
  sparkles: Sparkles,
  shield: Shield,
  cloud: Cloud,
  smartphone: Smartphone,
  database: Database
};

type CapabilitiesProps = {
  items: Capability[];
};

export function Capabilities({ items }: CapabilitiesProps) {
  return (
    <section className="section-shell section-anchor" aria-labelledby="capabilities-heading">
      <div className="page-shell">
        <SectionHeader
          label="Core Capabilities"
          title="Core capabilities"
          description="This portfolio is built around enterprise reliability, integration awareness, and a strong bias toward clean systems that are practical to operate."
        />

        <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
          {items.map((item, index) => {
            const Icon = iconMap[item.icon];

            return (
              <Reveal key={item.title} delay={index * 0.06}>
                <GlassCard
                  as="section"
                  aria-label={item.title}
                  className="h-full rounded-[28px] border-[rgba(255,255,255,0.1)] bg-[rgba(255,255,255,0.05)] p-6 transition-all duration-300 hover:-translate-y-1 hover:border-[rgba(40,240,211,0.18)] hover:shadow-[0_24px_80px_rgba(40,240,211,0.08)]"
                >
                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-[rgba(40,240,211,0.14)] bg-[rgba(40,240,211,0.08)] text-[var(--accent-teal)]">
                    <Icon className="h-5 w-5" />
                  </div>
                  <h3 className="mt-6 text-2xl font-semibold tracking-[-0.04em] text-[var(--text-primary)]">
                    {item.title}
                  </h3>
                  <p className="mt-4 text-sm leading-8 text-[var(--text-secondary)]">
                    {item.description}
                  </p>
                </GlassCard>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
