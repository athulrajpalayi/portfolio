import { ArrowRight } from "lucide-react";

import { Reveal } from "@/components/motion/reveal";
import { SignalLine } from "@/components/motion/signal-line";
import { GlassCard } from "@/components/primitives/glass-card";
import { SectionHeader } from "@/components/primitives/section-header";
import type { SystemNode } from "@/lib/content/site-content";

type SystemsArchitectureProps = {
  nodes: SystemNode[];
};

export function SystemsArchitecture({ nodes }: SystemsArchitectureProps) {
  return (
    <section id="systems" className="section-shell section-anchor">
      <div className="page-shell">
        <SectionHeader
          label="Systems & Integrations"
          title="Systems & integrations"
          description="The integration layer is presented as a clean enterprise pipeline. It shows how source systems, workflow logic, financial tools, storage, and reporting can move as one coordinated system."
        />

        <Reveal>
          <GlassCard className="rounded-[32px] bg-[rgba(255,255,255,0.04)] p-6 md:p-8">
            <div className="grid gap-6 lg:grid-cols-[1.15fr_0.85fr]">
              <div className="rounded-[28px] border border-[rgba(255,255,255,0.08)] bg-[rgba(255,255,255,0.03)] p-5 md:p-6">
                <div className="eyebrow mb-5">Signal Flow</div>
                <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
                  {nodes.map((node, index) => (
                    <div key={node.title} className="flex flex-1 flex-col gap-3 lg:flex-row lg:items-center">
                      <div className="min-w-0 flex-1 rounded-[24px] border border-[rgba(255,255,255,0.08)] bg-[rgba(9,12,21,0.8)] px-4 py-4">
                        <div className="text-xs uppercase tracking-[0.32em] text-[var(--accent-teal)]">
                          {node.label}
                        </div>
                        <div className="mt-2 text-lg font-semibold text-[var(--text-primary)]">
                          {node.title}
                        </div>
                        <p className="mt-2 text-sm leading-7 text-[var(--text-secondary)]">
                          {node.caption}
                        </p>
                      </div>
                      {index < nodes.length - 1 ? (
                        <>
                          <div className="hidden w-12 items-center justify-center lg:flex">
                            <SignalLine className="hidden lg:block" />
                            <ArrowRight className="relative -ml-2 h-4 w-4 text-[var(--accent-blue)]" />
                          </div>
                          <div className="flex items-center gap-3 lg:hidden">
                            <SignalLine orientation="vertical" className="ml-4" />
                          </div>
                        </>
                      ) : null}
                    </div>
                  ))}
                </div>
              </div>

              <div className="grid gap-4">
                <div className="rounded-[28px] border border-[rgba(255,255,255,0.08)] bg-[rgba(255,255,255,0.03)] p-6">
                  <div className="eyebrow mb-4">Integration Notes</div>
                  <ul className="space-y-3 text-sm leading-7 text-[var(--text-secondary)]">
                    <li>Normalized handoffs reduce brittle point-to-point logic.</li>
                    <li>Workflow checkpoints create traceable operational state.</li>
                    <li>Reporting persistence strengthens auditability and visibility.</li>
                  </ul>
                </div>
                <div className="rounded-[28px] border border-[rgba(59,130,246,0.12)] bg-[rgba(59,130,246,0.08)] p-6">
                  <div className="eyebrow mb-4 text-[var(--accent-blue)]">Why it matters</div>
                  <p className="text-sm leading-7 text-[var(--text-secondary)]">
                    This section proves systems thinking visually. It shows how operations, reporting,
                    finance, and workflow logic can move through a deliberate architecture rather than a
                    loose collection of tools.
                  </p>
                </div>
              </div>
            </div>
          </GlassCard>
        </Reveal>
      </div>
    </section>
  );
}
