import Link from "next/link";
import { ArrowRight, ShieldCheck } from "lucide-react";

import { MagneticButton } from "@/components/motion/magnetic-button";
import { ParallaxLayer } from "@/components/motion/parallax-layer";
import { Reveal } from "@/components/motion/reveal";
import { Badge } from "@/components/primitives/badge";
import { buttonVariants } from "@/components/primitives/button";
import { GlassCard } from "@/components/primitives/glass-card";
import type { MarketingContent } from "@/lib/content/site-content";
import { cn } from "@/lib/utils/cn";

type HeroProps = {
  hero: MarketingContent["hero"];
};

export function Hero({ hero }: HeroProps) {
  return (
    <section id="about" className="section-anchor relative overflow-hidden section-shell">
      <div className="page-shell grid items-center gap-12 lg:grid-cols-[1.05fr_0.95fr]">
        <Reveal className="relative">
          <Badge className="mb-6 bg-[rgba(59,130,246,0.1)] text-[var(--accent-blue)]">
            {hero.eyebrow}
          </Badge>
          <h1 className="max-w-4xl text-[42px] font-bold leading-[1.02] tracking-[-0.06em] text-[var(--text-primary)] md:text-[56px] md:leading-[1.05]">
            {hero.title}
            <span className="mt-2 block text-gradient">{hero.headlineAccent}</span>
          </h1>
          <p className="mt-6 max-w-2xl text-base leading-8 text-[var(--text-secondary)] md:text-xl md:leading-[1.7]">
            {hero.subtitle}
          </p>
          <p className="mt-4 max-w-2xl text-base leading-8 text-[var(--text-muted)] md:text-lg">
            {hero.intro}
          </p>

          <div className="mt-8 flex flex-wrap gap-3">
            {hero.chips.map((chip, index) => (
              <Reveal key={chip} delay={0.1 + index * 0.08}>
                <Badge className="border-[rgba(40,240,211,0.18)] bg-[rgba(255,255,255,0.05)] px-4 py-2 text-[var(--text-secondary)]">
                  {chip}
                </Badge>
              </Reveal>
            ))}
          </div>

          <div className="mt-10 flex flex-wrap gap-4">
            <MagneticButton>
              <Link href="#projects" className={buttonVariants({ variant: "primary" })}>
                View Projects
                <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
              </Link>
            </MagneticButton>
            <MagneticButton>
              <Link href="#contact" className={buttonVariants({ variant: "secondary" })}>
                Contact
              </Link>
            </MagneticButton>
          </div>

          <div className="mt-12 inline-flex items-center gap-4 rounded-full border border-[rgba(255,255,255,0.08)] bg-[rgba(255,255,255,0.04)] px-4 py-3 text-sm text-[var(--text-muted)]">
            <span className="relative flex h-2.5 w-2.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[rgba(40,240,211,0.7)]" />
              <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-[var(--accent-teal)]" />
            </span>
            {hero.statusLabel}
          </div>
        </Reveal>

        <Reveal delay={0.1}>
          <ParallaxLayer intensity={12} className="perspective-[1200px]">
            <div className="relative mx-auto max-w-[560px]">
              <div className="absolute -left-12 top-10 h-40 w-40 rounded-full bg-[rgba(40,240,211,0.16)] blur-3xl" />
              <div className="absolute -right-8 bottom-6 h-52 w-52 rounded-full bg-[rgba(59,130,246,0.18)] blur-3xl" />
              <GlassCard
                spotlight
                className="hero-panel-grid relative min-h-[540px] rounded-[32px] border-[rgba(255,255,255,0.12)] bg-[rgba(9,12,21,0.7)] p-6"
              >
                <div className="mb-5 flex items-center justify-between rounded-[22px] border border-[rgba(255,255,255,0.08)] bg-[rgba(255,255,255,0.03)] px-4 py-3">
                  <div>
                    <div className="text-xs uppercase tracking-[0.34em] text-[var(--text-muted)]">
                      Secure Ops Layer
                    </div>
                    <div className="mt-2 text-sm font-medium text-[var(--text-primary)]">
                      Enterprise Command Surface
                    </div>
                  </div>
                  <div className="rounded-full border border-[rgba(40,240,211,0.18)] bg-[rgba(40,240,211,0.12)] p-3 text-[var(--accent-teal)]">
                    <ShieldCheck className="h-5 w-5" />
                  </div>
                </div>

                <div className="grid gap-4 md:grid-cols-[1.1fr_0.9fr]">
                  <GlassCard className="rounded-[26px] bg-[rgba(255,255,255,0.04)] p-5">
                    <div className="text-xs uppercase tracking-[0.34em] text-[var(--text-muted)]">
                      Integration signal
                    </div>
                    <div className="mt-4 space-y-3">
                      {["ERP", "Middleware", "Creator", "Books"].map((item, index) => (
                        <div
                          key={item}
                          className="flex items-center justify-between rounded-2xl border border-[rgba(255,255,255,0.08)] bg-[rgba(255,255,255,0.03)] px-4 py-3"
                        >
                          <span className="text-sm text-[var(--text-primary)]">{item}</span>
                          <span className="text-xs text-[var(--text-muted)]">{`0${index + 1}`}</span>
                        </div>
                      ))}
                    </div>
                  </GlassCard>

                  <div className="grid gap-4">
                    <GlassCard className="rounded-[26px] bg-[rgba(255,255,255,0.04)] p-5">
                      <div className="text-xs uppercase tracking-[0.34em] text-[var(--text-muted)]">
                        AI / QA / Security
                      </div>
                      <div className="mt-5 space-y-3">
                        {[
                          { label: "AI pipelines", color: "bg-[rgba(40,240,211,0.95)]" },
                          { label: "Workflow QA", color: "bg-[rgba(59,130,246,0.95)]" },
                          { label: "Ethical hardening", color: "bg-[rgba(139,92,246,0.95)]" }
                        ].map((item) => (
                          <div key={item.label} className="flex items-center gap-3 text-sm text-[var(--text-secondary)]">
                            <span className={cn("h-2.5 w-2.5 rounded-full", item.color)} />
                            {item.label}
                          </div>
                        ))}
                      </div>
                    </GlassCard>
                    <GlassCard className="rounded-[26px] bg-[rgba(255,255,255,0.04)] p-5">
                      <div className="text-xs uppercase tracking-[0.34em] text-[var(--text-muted)]">
                        Reliability score
                      </div>
                      <div className="mt-4 text-5xl font-bold tracking-[-0.06em] text-[var(--text-primary)]">
                        98<span className="text-[var(--accent-teal)]">%</span>
                      </div>
                      <p className="mt-2 text-sm leading-7 text-[var(--text-muted)]">
                        Designed to communicate operational confidence, observability, and control.
                      </p>
                    </GlassCard>
                  </div>
                </div>

                <div className="mt-5 grid gap-4 md:grid-cols-3">
                  {[
                    "Zero clutter visual language",
                    "Signal-first system storytelling",
                    "High-trust enterprise presentation"
                  ].map((item) => (
                    <div
                      key={item}
                      className="rounded-2xl border border-[rgba(255,255,255,0.08)] bg-[rgba(255,255,255,0.03)] px-4 py-4 text-sm leading-7 text-[var(--text-secondary)]"
                    >
                      {item}
                    </div>
                  ))}
                </div>
              </GlassCard>
            </div>
          </ParallaxLayer>
        </Reveal>
      </div>
    </section>
  );
}
