import { NextResponse } from "next/server";

import {
  adminSessionCookieName,
  pendingTwoFactorCookieName,
  verifySessionToken
} from "@/lib/auth/session";
import { runOptionalDatabaseQuery } from "@/lib/db/prisma";

export const runtime = "nodejs";

export async function POST(request: Request) {
  const url = new URL(request.url);
  const sessionCookie = request.headers
    .get("cookie")
    ?.split(";")
    .map((part) => part.trim())
    .find((part) => part.startsWith(`${adminSessionCookieName}=`))
    ?.split("=")
    .slice(1)
    .join("=");

  const payload = sessionCookie ? await verifySessionToken(sessionCookie) : null;

  if (payload?.sid) {
    await runOptionalDatabaseQuery((db) =>
      db.session.deleteMany({
        where: {
          id: payload.sid
        }
      })
    );
  }

  const response = NextResponse.redirect(new URL("/admin/login", url));
  response.cookies.delete(adminSessionCookieName);
  response.cookies.delete(pendingTwoFactorCookieName);
  return response;
}
