import type { Metadata } from "next";

import "@/app/globals.css";

export const metadata: Metadata = {
  title: "Athulraj Palayi | Systems Modernization Portfolio",
  description:
    "Premium portfolio platform for Athulraj Palayi, focused on enterprise operations, systems modernization, cyber-aware delivery, and AI-enabled workflow design."
};

export default function RootLayout({
  children
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
