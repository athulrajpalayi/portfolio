"use client";

import Link from "next/link";
import { Download } from "lucide-react";
import { useEffect, useState } from "react";

import { Badge } from "@/components/primitives/badge";
import { buttonVariants } from "@/components/primitives/button";
import type { MarketingContent } from "@/lib/content/site-content";
import { cn } from "@/lib/utils/cn";

const navItems = [
  { href: "#about", label: "About" },
  { href: "#projects", label: "Projects" },
  { href: "#systems", label: "Systems" },
  { href: "#apps", label: "Apps" },
  { href: "#contact", label: "Contact" }
];

type NavbarProps = {
  site: MarketingContent["site"];
};

export function Navbar({ site }: NavbarProps) {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div className="sticky top-4 z-50 px-4 md:px-0">
      <div
        className={cn(
          "page-shell mt-4 flex items-center justify-between gap-4 rounded-[24px] border border-[rgba(255,255,255,0.08)] px-4 py-3 transition-all duration-500 md:px-6",
          scrolled
            ? "bg-[rgba(7,10,18,0.82)] shadow-[0_20px_90px_rgba(3,8,20,0.44)] backdrop-blur-xl"
            : "bg-[rgba(255,255,255,0.04)] backdrop-blur-md"
        )}
      >
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-2xl bg-[linear-gradient(135deg,rgba(40,240,211,0.18),rgba(59,130,246,0.2))] p-px">
            <div className="flex h-full w-full items-center justify-center rounded-2xl bg-[rgba(7,10,18,0.88)] text-sm font-semibold text-[var(--accent-teal)]">
              {site.monogram}
            </div>
          </div>
          <div>
            <div className="text-sm font-semibold tracking-[0.04em] text-[var(--text-primary)]">
              {site.displayName}
            </div>
            <Badge className="mt-1 border-transparent bg-[rgba(59,130,246,0.14)] px-2.5 py-0.5 text-[10px] tracking-[0.28em] text-[var(--text-muted)]">
              {site.navBadge}
            </Badge>
          </div>
        </div>

        <nav className="hidden items-center gap-7 text-sm text-[var(--text-secondary)] md:flex">
          {navItems.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="relative transition-colors duration-300 hover:text-[var(--text-primary)]"
            >
              {item.label}
              <span className="absolute inset-x-0 -bottom-1 h-px scale-x-0 bg-[image:var(--gradient-primary)] transition-transform duration-300 hover:scale-x-100" />
            </a>
          ))}
        </nav>

        <Link
          href={site.resumePath}
          className={cn(buttonVariants({ variant: "secondary" }), "hidden md:inline-flex")}
        >
          <Download className="h-4 w-4" />
          Download Resume
        </Link>
      </div>
    </div>
  );
}
