export type Capability = {
  title: string;
  description: string;
  icon: "workflow" | "sparkles" | "shield" | "cloud" | "smartphone" | "database";
};

export type ProjectMetric = {
  label: string;
  value: string;
};

export type CaseStudyStep = {
  title: string;
  detail: string;
};

export type FeaturedProject = {
  slug: string;
  title: string;
  summary: string;
  domain: string;
  tags: string[];
  metrics: ProjectMetric[];
  featuredLabel: string;
  challenge: string;
  architecture: string[];
  solution: string[];
  outcomes: string[];
  tools: string[];
  timeline: CaseStudyStep[];
};

export type SystemNode = {
  title: string;
  label: string;
  caption: string;
};

export type AppCardItem = {
  title: string;
  value: string;
  tag: string;
  icon: "phone" | "droplets" | "file-text" | "palette";
};

export type MarketingContent = {
  site: {
    displayName: string;
    monogram: string;
    navBadge: string;
    roleLabel: string;
    location: string;
    resumePath: string;
    domain: string;
    serverIp: string;
    footerNote: string;
    copyright: string;
  };
  hero: {
    eyebrow: string;
    title: string;
    headlineAccent: string;
    subtitle: string;
    intro: string;
    chips: string[];
    statusLabel: string;
  };
  capabilities: Capability[];
  featuredProjects: FeaturedProject[];
  systemsFlow: SystemNode[];
  apps: AppCardItem[];
  contact: {
    title: string;
    description: string;
    email: string;
    whatsapp: string;
    linkedin: string;
  };
};

export const marketingContent: MarketingContent = {
  site: {
    displayName: "Athulraj Palayi",
    monogram: "AP",
    navBadge: "Systems | Cyber | AI",
    roleLabel: "IT Operations / Systems Modernization Lead",
    location: "Dubai, UAE",
    resumePath: "/athulraj-palayi-resume.txt",
    domain: "athulrajpalayi.com",
    serverIp: "5.223.63.213",
    footerNote: "Built with precision, systems thinking, and modern automation.",
    copyright: "Copyright 2026 Athulraj Palayi"
  },
  hero: {
    eyebrow: "IT Operations / Systems Modernization Lead",
    title: "Athulraj Palayi",
    headlineAccent: "Secure systems, modern operations, and AI-ready workflow design.",
    subtitle: "Systems Modernization - QA Mindset - ERP Integrations - Automation",
    intro:
      "Athulraj builds secure internal systems, reporting layers, AI-enabled workflows, and operational tooling that help enterprise teams move faster with more precision at Shaji Coatings.",
    chips: ["CEH v10", "CISCP / CISCM", "Dubai, UAE"],
    statusLabel: "Scroll to explore the systems portfolio"
  },
  capabilities: [
    {
      title: "ERP Integrations",
      description:
        "Bridges finance, operations, and reporting systems into dependable connected workflows.",
      icon: "workflow"
    },
    {
      title: "Automation & Reporting",
      description:
        "Designs internal automations, dashboards, and data pipelines that remove repetitive manual work.",
      icon: "sparkles"
    },
    {
      title: "Mobile App QA + UX Review",
      description:
        "Applies QA discipline and product taste to uncover friction before it reaches users.",
      icon: "smartphone"
    },
    {
      title: "Cloud Deployments",
      description:
        "Ships maintainable applications with production-minded infrastructure and clean deployment paths.",
      icon: "cloud"
    },
    {
      title: "Security (Authorized Assessments)",
      description:
        "Approaches systems with ethical-hacker awareness, hardening workflows and interfaces early.",
      icon: "shield"
    },
    {
      title: "AI Production Pipelines",
      description:
        "Uses AI as an operational layer for media, automation, internal tooling, and workflow acceleration.",
      icon: "database"
    }
  ],
  featuredProjects: [
    {
      slug: "founder-story-film",
      title: "Founder Story Film - AI Brand Documentary",
      summary:
        "Produced a five-minute narrative brand film using AI-assisted creative tooling, post-production orchestration, and structured storytelling.",
      domain: "Creative Systems",
      tags: ["AI Video", "Story Systems", "Brand Ops"],
      featuredLabel: "Featured",
      metrics: [
        { label: "Reduced manual steps", value: "7 production passes" },
        { label: "Faster reporting", value: "2x tighter review loop" },
        { label: "Process visibility", value: "Unified asset pipeline" }
      ],
      challenge:
        "Traditional documentary-style edits were taking too long to iterate and review. The project needed a faster, more controllable pipeline without losing narrative quality.",
      architecture: [
        "Narrative planning and storyboard framing",
        "AI-assisted scene generation and visual refinement",
        "Structured review checkpoints for approvals",
        "Final timeline assembly with versioned exports"
      ],
      solution: [
        "Defined a modular production workflow for scene assets, voice, transitions, and approvals.",
        "Reduced creative bottlenecks by introducing repeatable prompt and review stages.",
        "Connected storytelling intent to measurable production checkpoints."
      ],
      outcomes: [
        "Created a premium founder story asset with enterprise-level polish.",
        "Improved stakeholder review speed with more transparent checkpoints.",
        "Established a repeatable AI-assisted media workflow for future campaigns."
      ],
      tools: ["Runway", "Premiere Pro", "Creative Prompt Systems", "Review QA"],
      timeline: [
        { title: "Narrative framing", detail: "Defined structure, tone, and target emotional arc." },
        { title: "Asset generation", detail: "Produced scenes, transitions, and supporting visuals." },
        { title: "Review loop", detail: "Shortened approvals with clearer, versioned handoffs." },
        { title: "Final delivery", detail: "Exported a polished five-minute film for presentation." }
      ]
    },
    {
      slug: "erp-sales-workflow-upgrade",
      title: "ERP + Sales Workflow Upgrade",
      summary:
        "Reworked operational handoffs between ERP, sales, and internal tracking so the team could move with less friction and better reporting discipline.",
      domain: "Enterprise Operations",
      tags: ["ERP", "Workflow Design", "Ops Reporting"],
      featuredLabel: "Operations",
      metrics: [
        { label: "Reduced manual steps", value: "12 repetitive actions removed" },
        { label: "Faster reporting", value: "Daily visibility" },
        { label: "Process visibility", value: "Cross-team status sync" }
      ],
      challenge:
        "Sales and operations workflows relied on fragmented handoffs, duplicate entry, and limited visibility into order progress.",
      architecture: [
        "ERP order source",
        "Sales workflow checkpoints",
        "Validation and exception handling",
        "Reporting layer for operational visibility"
      ],
      solution: [
        "Mapped the actual operational bottlenecks before changing the workflow.",
        "Standardized key transitions and surfaced health signals at each step.",
        "Built reporting hooks that made issues visible earlier."
      ],
      outcomes: [
        "Reduced repetitive coordination work across sales and operations.",
        "Improved reporting clarity for daily decision making.",
        "Created a cleaner foundation for future automation."
      ],
      tools: ["FirstBit", "Zoho", "PostgreSQL", "Power BI"],
      timeline: [
        { title: "Workflow audit", detail: "Documented fragile handoffs and duplicate work." },
        { title: "Control points", detail: "Introduced validation and shared checkpoints." },
        { title: "Reporting sync", detail: "Connected operational state to reporting outputs." },
        { title: "Operational adoption", detail: "Rolled out with clearer process visibility." }
      ]
    },
    {
      slug: "firstbit-zoho-sync",
      title: "FirstBit <-> Zoho Invoice Sync",
      summary:
        "Designed a structured integration layer between FirstBit and Zoho to improve invoice flow, visibility, and reliability across business systems.",
      domain: "Systems Integration",
      tags: ["FirstBit", "Zoho Creator", "Invoice Sync"],
      featuredLabel: "Integration",
      metrics: [
        { label: "Reduced manual steps", value: "Near-zero duplicate entry" },
        { label: "Faster reporting", value: "Near real-time sync state" },
        { label: "Process visibility", value: "Clear integration checkpoints" }
      ],
      challenge:
        "Invoice data was moving across disconnected systems, creating manual duplication and inconsistent downstream reporting.",
      architecture: [
        "FirstBit ERP source records",
        "Middleware normalization layer",
        "Zoho Creator process handling",
        "Zoho Books financial sync",
        "PostgreSQL reporting persistence"
      ],
      solution: [
        "Introduced a structured handoff layer instead of brittle point-to-point coupling.",
        "Added operational checkpoints and monitoring-oriented states.",
        "Designed the flow for traceability, not just transport."
      ],
      outcomes: [
        "Improved invoice processing confidence across systems.",
        "Made sync state easier to audit and troubleshoot.",
        "Created a reusable integration pattern for future connectors."
      ],
      tools: ["FirstBit ERP", "Zoho Creator", "Zoho Books", "PostgreSQL", "Power BI"],
      timeline: [
        { title: "Source mapping", detail: "Defined required entities and sync boundaries." },
        { title: "Middleware design", detail: "Normalized payloads and sync checkpoints." },
        { title: "Accounting sync", detail: "Connected records into downstream financial flow." },
        { title: "Visibility layer", detail: "Added reporting persistence and status tracking." }
      ]
    }
  ],
  systemsFlow: [
    {
      title: "FirstBit ERP",
      label: "Source of record",
      caption: "Financial and operational events originate here."
    },
    {
      title: "Middleware",
      label: "Normalization layer",
      caption: "Validates payload shape, sync state, and exception handling."
    },
    {
      title: "Zoho Creator",
      label: "Workflow control",
      caption: "Captures process logic, operational checkpoints, and review states."
    },
    {
      title: "Zoho Books",
      label: "Financial sync",
      caption: "Extends clean accounting visibility across downstream flows."
    },
    {
      title: "PostgreSQL",
      label: "Reporting persistence",
      caption: "Stores clean records for analysis and historical reliability."
    },
    {
      title: "Power BI",
      label: "Operational visibility",
      caption: "Surfaces decision-ready dashboards and executive reporting."
    }
  ],
  apps: [
    {
      title: "Video Calling App",
      value: "Low-latency WebRTC-based collaboration experience for direct browser communication.",
      tag: "WebRTC",
      icon: "phone"
    },
    {
      title: "Water Reminder App",
      value: "Habit-forming hydration reminders with clear feedback and dependable notification logic.",
      tag: "Wellness Utility",
      icon: "droplets"
    },
    {
      title: "PDF Tools App",
      value: "Focused document utility flow for conversion, merging, and faster internal document handling.",
      tag: "Productivity",
      icon: "file-text"
    },
    {
      title: "Color Mixing App",
      value: "Practical helper for exploring mix ratios and translating color ideas into usable references.",
      tag: "Utility",
      icon: "palette"
    }
  ],
  contact: {
    title: "Let's build something reliable.",
    description:
      "For enterprise workflow upgrades, AI-enabled internal tools, integration design, QA-heavy product work, or secure systems thinking.",
    email: "athulraj@example.com",
    whatsapp: "https://wa.me/971000000000",
    linkedin: "https://www.linkedin.com/in/athulraj-palayi"
  }
};

export function getProjectBySlug(slug: string) {
  return marketingContent.featuredProjects.find((project) => project.slug === slug) ?? null;
}
