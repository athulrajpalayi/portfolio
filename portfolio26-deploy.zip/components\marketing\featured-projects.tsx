import Link from "next/link";
import { ArrowUpRight } from "lucide-react";

import { Reveal } from "@/components/motion/reveal";
import { Badge } from "@/components/primitives/badge";
import { GlassCard } from "@/components/primitives/glass-card";
import { SectionHeader } from "@/components/primitives/section-header";
import type { FeaturedProject } from "@/lib/content/site-content";
import { projectHref } from "@/lib/content/mappers";

type FeaturedProjectsProps = {
  projects: FeaturedProject[];
};

export function FeaturedProjects({ projects }: FeaturedProjectsProps) {
  return (
    <section
      id="projects"
      className="section-shell section-anchor"
      aria-labelledby="featured-projects-heading"
    >
      <div className="page-shell">
        <SectionHeader
          label="Featured Projects"
          title="Featured projects"
          description="Each project is presented like a product story: what was broken, how the architecture moved, and what became more reliable after the work."
        />

        <div className="grid gap-6">
          {projects.map((project, index) => (
            <Reveal key={project.slug} delay={index * 0.08}>
              <GlassCard className="group overflow-hidden rounded-[32px] p-0 transition-all duration-300 hover:-translate-y-1 hover:border-[rgba(59,130,246,0.22)] hover:shadow-[0_24px_80px_rgba(59,130,246,0.12)]">
                <div className="grid gap-0 lg:grid-cols-[1.05fr_0.95fr]">
                  <div className="relative overflow-hidden border-b border-[rgba(255,255,255,0.08)] p-7 lg:border-b-0 lg:border-r lg:p-8">
                    <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(40,240,211,0.12),transparent_38%),radial-gradient(circle_at_bottom_right,rgba(139,92,246,0.18),transparent_44%)] opacity-80 transition-opacity duration-500 group-hover:opacity-100" />
                    <div className="absolute inset-0 translate-y-2 bg-[linear-gradient(135deg,rgba(255,255,255,0.06),transparent_65%)] transition-transform duration-500 group-hover:translate-y-0" />
                    <div className="relative z-10">
                      <Badge className="bg-[rgba(40,240,211,0.12)] text-[var(--accent-teal)]">
                        {project.featuredLabel}
                      </Badge>
                      <h3 className="mt-6 text-3xl font-semibold tracking-[-0.05em] text-[var(--text-primary)]">
                        {project.title}
                      </h3>
                      <p className="mt-4 max-w-xl text-base leading-8 text-[var(--text-secondary)]">
                        {project.summary}
                      </p>
                      <div className="mt-8 flex flex-wrap gap-2">
                        {project.tags.map((tag) => (
                          <Badge key={tag} className="text-[var(--text-muted)]">
                            {tag}
                          </Badge>
                        ))}
                      </div>

                      <Link
                        href={projectHref(project)}
                        className="mt-10 inline-flex items-center gap-2 text-sm font-medium text-[var(--text-primary)]"
                      >
                        View Case Study
                        <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1 group-hover:-translate-y-1" />
                      </Link>
                    </div>
                  </div>

                  <div className="grid gap-4 p-7 lg:p-8">
                    {project.metrics.map((metric) => (
                      <div
                        key={metric.label}
                        className="rounded-[24px] border border-[rgba(255,255,255,0.08)] bg-[rgba(255,255,255,0.04)] px-5 py-5 transition-colors duration-300 group-hover:border-[rgba(255,255,255,0.12)]"
                      >
                        <div className="text-xs uppercase tracking-[0.32em] text-[var(--text-muted)]">
                          {metric.label}
                        </div>
                        <div className="mt-3 text-xl font-semibold tracking-[-0.04em] text-[var(--text-primary)]">
                          {metric.value}
                        </div>
                      </div>
                    ))}
                    <div className="rounded-[24px] border border-[rgba(59,130,246,0.14)] bg-[rgba(59,130,246,0.09)] px-5 py-5 text-sm leading-8 text-[var(--text-secondary)]">
                      Domain focus: <span className="text-[var(--text-primary)]">{project.domain}</span>
                    </div>
                  </div>
                </div>
              </GlassCard>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
